from __future__ import annotations

import asyncio


class CustomLoop(asyncio.SelectorEventLoop):
    pass
